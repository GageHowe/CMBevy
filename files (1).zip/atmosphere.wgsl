#import bevy_pbr::forward_io::VertexOutput

@group(#{MATERIAL_BIND_GROUP}) @binding(0) var<uniform> atmo: AtmosphereUniforms;

// Must match AtmosphereUniforms in atmosphere_material.rs field-for-field.
// WGSL packs vec3<f32> as 12 bytes but aligns to 16b — the f32 after each
// vec3 fills the trailing 4 bytes of that slot naturally, so no manual
// padding is needed.
struct AtmosphereUniforms {
    planet_center:     vec3<f32>,
    planet_radius:     f32,        // fills vec3 slot
    atmosphere_radius: f32,
    rayleigh_coeff:    vec3<f32>,  // re-aligns to 16b boundary
    rayleigh_scale_h:  f32,        // fills vec3 slot
    sun_dir:           vec3<f32>,
    sun_intensity:     f32,
    camera_pos:        vec3<f32>,
    view_samples:      u32,
    light_samples:     u32,
}

// ── Helpers ───────────────────────────────────────────────────────────────────

// Returns (near, far) intersection distances for a ray vs sphere.
// Returns vec2(-1.0) on miss.
fn ray_sphere(origin: vec3<f32>, dir: vec3<f32>, center: vec3<f32>, radius: f32) -> vec2<f32> {
    let oc = origin - center;
    let b  = dot(oc, dir);
    let c  = dot(oc, oc) - radius * radius;
    let d  = b * b - c;
    if d < 0.0 { return vec2(-1.0); }
    let sq = sqrt(d);
    return vec2(-b - sq, -b + sq);
}

fn rayleigh_phase(cos_theta: f32) -> f32 {
    return (3.0 / (16.0 * 3.14159265)) * (1.0 + cos_theta * cos_theta);
}

fn density(pos: vec3<f32>) -> f32 {
    let altitude = length(pos - atmo.planet_center) - atmo.planet_radius;
    return exp(-max(altitude, 0.0) / atmo.rayleigh_scale_h);
}

// ── Main scatter function ─────────────────────────────────────────────────────

fn scatter(ray_origin: vec3<f32>, ray_dir: vec3<f32>) -> vec3<f32> {
    let atmo_hit = ray_sphere(ray_origin, ray_dir, atmo.planet_center, atmo.atmosphere_radius);
    if atmo_hit.x < 0.0 && atmo_hit.y < 0.0 { return vec3(0.0); }

    let t_start = max(atmo_hit.x, 0.0);
    let planet_hit = ray_sphere(ray_origin, ray_dir, atmo.planet_center, atmo.planet_radius);
    let t_end = select(atmo_hit.y, min(planet_hit.x, atmo_hit.y), planet_hit.x > 0.0);

    if t_end <= t_start { return vec3(0.0); }

    // Hoist loop-invariant conversions out of the loops
    let n_view      = f32(atmo.view_samples);
    let n_light     = f32(atmo.light_samples);
    let seg_len     = (t_end - t_start) / n_view;

    var optical_depth_view = 0.0;
    var total_light        = vec3(0.0);

    for (var i = 0u; i < atmo.view_samples; i++) {
        let sample  = ray_origin + ray_dir * (t_start + (f32(i) + 0.5) * seg_len);
        let d_view  = density(sample) * seg_len;
        optical_depth_view += d_view;

        let sun_hit = ray_sphere(sample, atmo.sun_dir, atmo.planet_center, atmo.atmosphere_radius);
        let sun_seg = sun_hit.y / n_light;
        var optical_depth_sun = 0.0;
        for (var j = 0u; j < atmo.light_samples; j++) {
            let sun_sample = sample + atmo.sun_dir * ((f32(j) + 0.5) * sun_seg);
            optical_depth_sun += density(sun_sample) * sun_seg;
        }

        let tau        = atmo.rayleigh_coeff * (optical_depth_view + optical_depth_sun);
        let extinction = exp(-tau);
        total_light   += extinction * d_view;
    }

    let cos_theta = dot(ray_dir, atmo.sun_dir);
    return atmo.sun_intensity * rayleigh_phase(cos_theta) * atmo.rayleigh_coeff * total_light;
}

// ── Fragment entry point ──────────────────────────────────────────────────────

@fragment
fn fragment(in: VertexOutput) -> @location(0) vec4<f32> {
    let world_pos = in.world_position.xyz;
    let ray_origin = atmo.camera_pos;
    let ray_dir    = normalize(world_pos - atmo.camera_pos);

    let colour = scatter(ray_origin, ray_dir);
    let alpha  = clamp(dot(colour, vec3(0.299, 0.587, 0.114)) * 3.0, 0.0, 1.0);

    return vec4(colour, alpha);
}
