// atmosphere_material.rs
//
// Drop-in Bevy 0.18 atmosphere shell material.
// Usage:
//   1. Add `AtmospherePlugin` to your app.
//   2. For each planet, spawn a parent entity and call `spawn_planet`, or
//      manually attach `AtmosphereMaterial` to a sphere shell mesh.

use bevy::{
    prelude::*,
    reflect::TypePath,
    render::render_resource::{AsBindGroup, ShaderRef, ShaderType},
};

const SHADER_PATH: &str = "shaders/atmosphere.wgsl";

// ── Plugin ────────────────────────────────────────────────────────────────────

pub struct AtmospherePlugin;

impl Plugin for AtmospherePlugin {
    fn build(&self, app: &mut App) {
        app.add_plugins(MaterialPlugin::<AtmosphereMaterial> {
            prepass_enabled: false,
            ..default()
        })
        .add_systems(Update, (sync_atmosphere_camera, sync_planet_centers));
    }
}

// ── Uniform struct ────────────────────────────────────────────────────────────
//
// IMPORTANT: this struct is what actually gets uploaded to the GPU.
// It must be a single #[derive(ShaderType)] value so Bevy packs it as one
// uniform buffer whose layout matches the WGSL struct exactly.
//
// Using separate #[uniform(0)] fields on the material would create multiple
// independent bindings that do NOT match a single WGSL struct — silent
// garbage values on the GPU.
//
// Field order here must match the WGSL struct field order exactly.
// WGSL vec3<f32> is 16-byte aligned (padded to vec4 boundary).

#[derive(ShaderType, Clone, Default)]
pub struct AtmosphereUniforms {
    pub planet_center:     Vec3,
    pub planet_radius:     f32,
    pub atmosphere_radius: f32,
    pub rayleigh_coeff:    Vec3,
    pub rayleigh_scale_h:  f32,
    pub sun_dir:           Vec3,
    pub sun_intensity:     f32,
    pub camera_pos:        Vec3,
    pub view_samples:      u32,
    pub light_samples:     u32,
    // ShaderType handles trailing padding automatically
}

// ── Material ──────────────────────────────────────────────────────────────────

/// Marker component on the atmosphere shell entity.
/// Required by `sync_planet_centers` to track the parent planet transform.
#[derive(Component)]
pub struct AtmosphereShell;

/// Attach to a sphere mesh whose radius is slightly larger than the planet.
#[derive(Asset, TypePath, AsBindGroup, Clone)]
pub struct AtmosphereMaterial {
    /// Single packed uniform — layout must match the WGSL AtmosphereUniforms struct.
    #[uniform(0)]
    pub uniforms: AtmosphereUniforms,
}

impl AtmosphereMaterial {
    /// Earth-like preset. Radii in your world units.
    pub fn earth_like(
        planet_center: Vec3,
        planet_radius: f32,
        atmosphere_radius: f32,
        sun_dir: Vec3,
    ) -> Self {
        Self {
            uniforms: AtmosphereUniforms {
                planet_center,
                planet_radius,
                atmosphere_radius,
                rayleigh_coeff:   Vec3::new(5.8e-6, 13.5e-6, 33.1e-6),
                rayleigh_scale_h: planet_radius * 0.08,
                sun_dir:          sun_dir.normalize(),
                sun_intensity:    20.0,
                camera_pos:       Vec3::ZERO, // filled by sync_atmosphere_camera
                view_samples:     12,
                light_samples:    6,
            },
        }
    }
}

impl Material for AtmosphereMaterial {
    fn fragment_shader() -> ShaderRef {
        SHADER_PATH.into()
    }

    fn alpha_mode(&self) -> AlphaMode {
        AlphaMode::Add
    }
}

// ── Systems ───────────────────────────────────────────────────────────────────

/// Writes camera world position into every AtmosphereMaterial.
/// Uses `Changed<GlobalTransform>` so it only runs when the camera actually moves,
/// avoiding spurious change-detection dirty marks every frame.
pub fn sync_atmosphere_camera(
    camera_q: Query<&GlobalTransform, (With<Camera3d>, Changed<GlobalTransform>)>,
    mut materials: ResMut<Assets<AtmosphereMaterial>>,
) {
    let Ok(cam_xf) = camera_q.single() else { return };
    let cam_pos = cam_xf.translation();

    for (_, mat) in materials.iter_mut() {
        mat.uniforms.camera_pos = cam_pos;
    }
}

/// Keeps `planet_center` correct for moving planets by reading the parent
/// entity's world-space translation each frame.
///
/// Requires:
///   - `AtmosphereShell` marker on the shell entity
///   - shell entity is a child of the planet entity
pub fn sync_planet_centers(
    shell_q: Query<(&MeshMaterial3d<AtmosphereMaterial>, &Parent), With<AtmosphereShell>>,
    parent_q: Query<&GlobalTransform>,
    mut materials: ResMut<Assets<AtmosphereMaterial>>,
) {
    for (mat_handle, parent) in &shell_q {
        let Ok(parent_xf) = parent_q.get(parent.get()) else { continue };
        let planet_center = parent_xf.translation();

        if let Some(mat) = materials.get_mut(mat_handle) {
            if mat.uniforms.planet_center != planet_center {
                mat.uniforms.planet_center = planet_center;
            }
        }
    }
}

// ── Spawn helper ──────────────────────────────────────────────────────────────

/// Spawns a planet (opaque sphere) + atmosphere shell under a parent entity.
/// Returns the parent entity id.
pub fn spawn_planet(
    commands: &mut Commands,
    meshes: &mut Assets<Mesh>,
    std_materials: &mut Assets<StandardMaterial>,
    atmo_materials: &mut Assets<AtmosphereMaterial>,
    position: Vec3,
    planet_radius: f32,
    sun_dir: Vec3,
    surface_color: Color,
) -> Entity {
    let atmo_radius = planet_radius * 1.05;

    let surface_mesh = meshes.add(Sphere::new(planet_radius).mesh().ico(5).unwrap());
    let atmo_mesh    = meshes.add(Sphere::new(atmo_radius).mesh().ico(5).unwrap());

    let surface_mat = std_materials.add(StandardMaterial {
        base_color: surface_color,
        perceptual_roughness: 0.8,
        ..default()
    });

    // planet_center starts as Vec3::ZERO; sync_planet_centers corrects it
    // to world position on the first frame.
    let atmo_mat = atmo_materials.add(AtmosphereMaterial::earth_like(
        Vec3::ZERO,
        planet_radius,
        atmo_radius,
        sun_dir,
    ));

    commands
        .spawn((
            Transform::from_translation(position),
            Visibility::default(),
        ))
        .with_children(|parent| {
            parent.spawn((
                Mesh3d(surface_mesh),
                MeshMaterial3d(surface_mat),
            ));
            parent.spawn((
                AtmosphereShell,
                Mesh3d(atmo_mesh),
                MeshMaterial3d(atmo_mat),
            ));
        })
        .id()
}
